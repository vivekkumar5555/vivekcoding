'''To solve the error in the code, we need to fix the indentation of the nested functions rect, tri, and cir. In Python, indentation is crucial for defining nested blocks of code. Here's the corrected code:'''

def sqr(a):
    s = a**2
    p = a*4
    print(f"area of the square is: {s} & perimeter is: {p}")
 
def rect(l, b):
        arr = l * b
        p = 2 * (l + b)
        print(f"area of rectangle is: {arr} & perimeter is: {p}")

def tri(a, b, c, height):
            art = (1/2) * b * height
            p = a + b + c
            print(f"area of triangle is: {art} & perimeter of triangle is {p}")

def cir(r):
            ar = 3.141592653589793 * r**2
            p = 2 * 3.141592653589793 * r
            print(f"area of circle is: {ar} & perimeter of circle is: {p}")
           




               