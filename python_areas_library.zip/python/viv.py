import Area_v as av
av.sqr(10)
av.cir(10)
av.tri(2,6,8,10)
av.rect(20,10)